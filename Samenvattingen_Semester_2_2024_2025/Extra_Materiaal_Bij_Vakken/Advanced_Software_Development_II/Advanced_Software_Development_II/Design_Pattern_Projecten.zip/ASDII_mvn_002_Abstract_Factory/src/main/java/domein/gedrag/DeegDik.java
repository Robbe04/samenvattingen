package domein.gedrag;

import domein.interfaces.Deeg;

/**
 * Stap 2 van het Abstract Factory Pattern: implementatie van de gedragen
 */
public class DeegDik implements Deeg {

	@Override
	public String toString() {
		return "Dik deeg";
	}

}
