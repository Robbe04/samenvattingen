package domein.interfaces;

/**
 * Stap 1 van het Abstract Factory Pattern: maken van de gedragen hun interfaces
 */
public interface Deeg {
	@Override
	String toString();
}
