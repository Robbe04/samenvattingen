package domein.ingredientfactory;

import domein.interfaces.Deeg;
import domein.interfaces.Kaas;
import domein.interfaces.Saus;

/**
 * Stap 3 van het Abstract Factory Pattern: maken van de abstracte klasse die de
 * methodes definieert voor het maken van de verschillende ingrediënten
 */
public abstract class PizzaIngredientFactory {

	public abstract Deeg maakDeeg();

	public abstract Saus maakSaus();

	public abstract Kaas maakKaas();
}
