package domein.interfaces;

public interface Saus {
	String toString();
}
