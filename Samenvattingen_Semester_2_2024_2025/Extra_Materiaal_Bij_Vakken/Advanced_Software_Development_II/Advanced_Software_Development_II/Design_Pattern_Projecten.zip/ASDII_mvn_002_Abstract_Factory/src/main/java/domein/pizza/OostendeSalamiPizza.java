package domein.pizza;

import domein.ingredientfactory.PizzaIngredientFactory;

public class OostendeSalamiPizza extends Pizza {

	public OostendeSalamiPizza(PizzaIngredientFactory pizzaIngredientFactory) {
		super(pizzaIngredientFactory);
	}

	@Override
	public String toString() {
		return "Oostende Salami Pizza met " + getDeeg() + ", " + getSaus() + " en " + getKaas();
	}

}
