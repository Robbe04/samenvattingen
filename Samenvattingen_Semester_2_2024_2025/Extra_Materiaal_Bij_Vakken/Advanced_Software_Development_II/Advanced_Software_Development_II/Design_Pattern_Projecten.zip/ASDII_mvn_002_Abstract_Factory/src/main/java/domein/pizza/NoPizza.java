package domein.pizza;

import domein.ingredientfactory.PizzaIngredientFactory;

public class NoPizza extends Pizza {

	public NoPizza(PizzaIngredientFactory pizzaIngredientFactory) {
		super(pizzaIngredientFactory);
	}

	@Override
	public String toString() {
		return "We don't have that pizza!";
	}

}
