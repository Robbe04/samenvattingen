package domein.gedrag;

import domein.interfaces.Saus;

public class SausTomaat implements Saus {

	@Override
	public String toString() {
		return "Tomatensaus";
	}

}
