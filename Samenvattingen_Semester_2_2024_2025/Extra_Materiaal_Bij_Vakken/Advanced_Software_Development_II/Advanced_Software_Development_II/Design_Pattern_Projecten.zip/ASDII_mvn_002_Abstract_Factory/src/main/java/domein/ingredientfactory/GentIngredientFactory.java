package domein.ingredientfactory;

import domein.gedrag.DeegDik;
import domein.gedrag.KaasParmezaan;
import domein.gedrag.SausTomaat;
import domein.interfaces.Deeg;
import domein.interfaces.Kaas;
import domein.interfaces.Saus;

/**
 * Stap 4 van het Abstract Factory Pattern: implementatie van de concrete
 * ingredient factory
 */
public class GentIngredientFactory extends PizzaIngredientFactory {

	@Override
	public Deeg maakDeeg() {
		return new DeegDik();
	}

	@Override
	public Saus maakSaus() {
		return new SausTomaat();
	}

	@Override
	public Kaas maakKaas() {
		return new KaasParmezaan();
	}

}
