package domein.pizza;

import domein.ingredientfactory.PizzaIngredientFactory;

public class OostendeBBQPizza extends Pizza {

	public OostendeBBQPizza(PizzaIngredientFactory pizzaIngredientFactory) {
		super(pizzaIngredientFactory);
	}

	@Override
	public String toString() {
		return "Oostende BBQ Pizza met " + getDeeg() + ", " + getSaus() + " en " + getKaas();
	}

}
