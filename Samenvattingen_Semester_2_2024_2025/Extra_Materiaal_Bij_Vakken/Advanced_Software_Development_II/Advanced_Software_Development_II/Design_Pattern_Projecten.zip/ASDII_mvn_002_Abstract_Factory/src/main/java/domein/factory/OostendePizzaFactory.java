package domein.factory;

import domein.ingredientfactory.OostendeIngredientFactory;
import domein.pizza.NoPizza;
import domein.pizza.OostendeBBQPizza;
import domein.pizza.OostendeSalamiPizza;
import domein.pizza.Pizza;

public class OostendePizzaFactory extends PizzaFactory {

	@Override
	protected Pizza createPizza(String item) {
		Pizza pizza = null;

		switch (item.toLowerCase()) {
		case "bbq":
			pizza = new OostendeBBQPizza(new OostendeIngredientFactory());
			break;
		case "salami":
			pizza = new OostendeSalamiPizza(new OostendeIngredientFactory());
			break;
		default:
			pizza = new NoPizza(new OostendeIngredientFactory());
			break;
		}

		return pizza;
	}

}
