package domein.pizza;

import domein.ingredientfactory.PizzaIngredientFactory;
import domein.interfaces.Deeg;
import domein.interfaces.Kaas;
import domein.interfaces.Saus;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Getter(value = AccessLevel.PROTECTED)
@Setter(value = AccessLevel.PROTECTED)
public abstract class Pizza {
	private Deeg deeg;
	private Saus saus;
	private Kaas kaas;
	private PizzaIngredientFactory pizzaIngredientFactory;

	public Pizza(PizzaIngredientFactory pizzaIngredientFactory) {
		this.pizzaIngredientFactory = pizzaIngredientFactory;
		this.deeg = pizzaIngredientFactory.maakDeeg();
		this.saus = pizzaIngredientFactory.maakSaus();
		this.kaas = pizzaIngredientFactory.maakKaas();
	}

	public abstract String toString();

}
