package domein.factory;

import domein.ingredientfactory.GentIngredientFactory;
import domein.pizza.GentBBQPizza;
import domein.pizza.NoPizza;
import domein.pizza.Pizza;

public class GentPizzaFactory extends PizzaFactory {

	@Override
	protected Pizza createPizza(String item) {
		Pizza pizza = null;

		switch (item.toLowerCase()) {
		case "bbq":
			pizza = new GentBBQPizza(new GentIngredientFactory());
			break;
		case "salami":
			pizza = new GentBBQPizza(new GentIngredientFactory());
			break;
		default:
			pizza = new NoPizza(new GentIngredientFactory());
			break;
		}

		return pizza;
	}

}
