package domein.pizza;

import domein.ingredientfactory.PizzaIngredientFactory;

public class GentSalamiPizza extends Pizza {

	public GentSalamiPizza(PizzaIngredientFactory pizzaIngredientFactory) {
		super(pizzaIngredientFactory);
	}

	@Override
	public String toString() {
		return "Gent Salami Pizza met " + getDeeg() + ", " + getSaus() + " en " + getKaas();
	}

}
