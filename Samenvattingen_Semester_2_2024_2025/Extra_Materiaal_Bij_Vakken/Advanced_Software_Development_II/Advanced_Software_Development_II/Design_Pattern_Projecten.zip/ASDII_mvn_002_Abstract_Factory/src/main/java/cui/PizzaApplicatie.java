package cui;

import domein.factory.GentPizzaFactory;
import domein.factory.OostendePizzaFactory;
import domein.factory.PizzaFactory;
import domein.pizza.Pizza;

public class PizzaApplicatie {
	public static void main(String[] args) {
		PizzaFactory oostendeFactory = new OostendePizzaFactory();
		Pizza oostendePizza = oostendeFactory.orderPizza("bbq");
		System.out.println(oostendePizza);

		PizzaFactory gentFactory = new GentPizzaFactory();
		Pizza gentPizza = gentFactory.orderPizza("salami");
		System.out.println(gentPizza);
	}
}
