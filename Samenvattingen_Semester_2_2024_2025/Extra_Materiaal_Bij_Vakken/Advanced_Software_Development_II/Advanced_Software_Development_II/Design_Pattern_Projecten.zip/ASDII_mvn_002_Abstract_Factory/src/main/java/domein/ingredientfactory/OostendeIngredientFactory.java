package domein.ingredientfactory;

import domein.gedrag.DeegDun;
import domein.gedrag.KaasParmezaan;
import domein.gedrag.SausLook;
import domein.interfaces.Deeg;
import domein.interfaces.Kaas;
import domein.interfaces.Saus;

public class OostendeIngredientFactory extends PizzaIngredientFactory {

	@Override
	public Deeg maakDeeg() {
		return new DeegDun();
	}

	@Override
	public Saus maakSaus() {
		return new SausLook();
	}

	@Override
	public Kaas maakKaas() {
		return new KaasParmezaan();
	}

}
