package domein.interfaces;

public interface Kaas {
	String toString();
}
