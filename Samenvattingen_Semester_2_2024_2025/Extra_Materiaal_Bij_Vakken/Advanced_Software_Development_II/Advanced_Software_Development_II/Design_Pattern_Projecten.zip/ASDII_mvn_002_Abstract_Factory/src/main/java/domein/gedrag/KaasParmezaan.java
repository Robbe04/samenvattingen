package domein.gedrag;

import domein.interfaces.Kaas;

public class KaasParmezaan implements Kaas {

	@Override
	public String toString() {
		return "Parmezaanse kaas";
	}

}
