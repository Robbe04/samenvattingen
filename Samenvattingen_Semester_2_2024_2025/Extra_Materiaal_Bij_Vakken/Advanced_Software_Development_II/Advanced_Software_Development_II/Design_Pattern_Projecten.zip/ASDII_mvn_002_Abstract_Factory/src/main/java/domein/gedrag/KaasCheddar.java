package domein.gedrag;

import domein.interfaces.Kaas;

public class KaasCheddar implements Kaas {

	@Override
	public String toString() {
		return "Cheddar kaas";
	}

}
