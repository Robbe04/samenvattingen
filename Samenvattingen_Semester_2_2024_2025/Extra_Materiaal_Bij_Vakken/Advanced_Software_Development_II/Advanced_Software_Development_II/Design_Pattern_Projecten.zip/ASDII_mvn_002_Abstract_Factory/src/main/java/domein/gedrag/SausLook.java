package domein.gedrag;

import domein.interfaces.Saus;

public class SausLook implements Saus {

	@Override
	public String toString() {
		return "Looksaus";
	}

}
