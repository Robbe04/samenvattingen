package domein.factory;

import domein.pizza.Pizza;

/**
 * Stap 5: Maken van de concrete pizza klassen en de factorys om te bestellen
 */
public abstract class PizzaFactory {
	protected abstract Pizza createPizza(String item);

	public Pizza orderPizza(String type) {
		Pizza pizza = createPizza(type);

		System.out.println("--- Making a " + pizza.getClass().getSimpleName());
		return pizza;
	}
}
