package domein.pizza;

import domein.ingredientfactory.PizzaIngredientFactory;

/**
 * Stap 5: Maken van de concrete pizza klassen
 */
public class GentBBQPizza extends Pizza {

	public GentBBQPizza(PizzaIngredientFactory pizzaIngredientFactory) {
		super(pizzaIngredientFactory);
	}

	@Override
	public String toString() {
		return "Gent BBQ Pizza met " + getDeeg() + ", " + getSaus() + " en " + getKaas();
	}

}
