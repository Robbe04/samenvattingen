package domein.gedrag;

import domein.interfaces.Deeg;

public class DeegDun implements Deeg {

	@Override
	public String toString() {
		return "Dun deeg";
	}
}
