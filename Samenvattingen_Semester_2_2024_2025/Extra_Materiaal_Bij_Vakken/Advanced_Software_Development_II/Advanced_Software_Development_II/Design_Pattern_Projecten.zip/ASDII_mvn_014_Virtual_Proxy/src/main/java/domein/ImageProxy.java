package domein;

import java.awt.Component;
import java.awt.Graphics;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.Icon;
import javax.swing.ImageIcon;

public class ImageProxy implements Icon {

	private Icon imageIcon;
	private final URL imageUrl;
	private final ExecutorService executor;

	public ImageProxy(URL url) {
		this.imageUrl = url;
		this.executor = Executors.newSingleThreadExecutor();
	}

	@Override
	public int getIconWidth() {
		return (imageIcon != null) ? imageIcon.getIconWidth() : 800;
	}

	@Override
	public int getIconHeight() {
		return (imageIcon != null) ? imageIcon.getIconHeight() : 600;
	}

	@Override
	public void paintIcon(final Component c, Graphics g, int x, int y) {
		if (imageIcon != null) {
			imageIcon.paintIcon(c, g, x, y);
		} else {

			g.drawString("cd cover wordt geladen, wachten a.u.b. ...", x + 300, y + 190);
			executor.execute(() -> {
				try {
					Thread.sleep(2000); // Simuleer extra vertraging
					imageIcon = new ImageIcon(imageUrl, "cd-cover");
					c.repaint();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					executor.shutdown();
				}
			});
		}
	}
}