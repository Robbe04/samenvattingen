package main;

import domein.ImageComponent;
import domein.ImageProxy;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import javax.swing.Icon;
import javax.swing.JFrame;
import static javax.swing.JFrame.*;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class VirtualProxy {

    private ImageComponent imageComponent;
    private final JFrame frame;
    private final JMenuBar menuBar;
    private final JMenu menu;
    private final Map<String, String> cds;

    public static void main(String[] args) {
        new VirtualProxy();
    }

    public VirtualProxy() {
    	frame = new JFrame("CD Cover Viewer");
    	
        cds = new HashMap<>();
        cds.put("Ambient: Music for Airports", "http://ecx.images-amazon.com/images/I/41FNZAYSMML.jpg");
        cds.put("Ima", "http://g-ecx.images-amazon.com/images/G/01/ciu/0c/9a/0328793509a04478b6886110.L._SY300_.jpg");
        cds.put("Selected Ambient Works, Vol. 2", "http://ecx.images-amazon.com/images/I/51V0KZR79EL._SY300__PJautoripBadge,BottomRight,4,-40_OU11__.jpg");

        URL initialURL = getCDUrl("Selected Ambient Works, Vol. 2");
        
        menuBar = new JMenuBar();
        menu = new JMenu("Favorite CDs");
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);

        cds.keySet().forEach(cdTitle -> {
            JMenuItem menuItem = new JMenuItem(cdTitle);
            menu.add(menuItem);
            
            menuItem.addActionListener(event -> {
                imageComponent.setIcon(new ImageProxy(getCDUrl(event.getActionCommand())));
                frame.repaint();
            });
        });
        
        // set up frame and menus
        Icon icon = new ImageProxy(initialURL);
        
        imageComponent = new ImageComponent(icon);
        frame.getContentPane().add(imageComponent);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setVisible(true);

    }

    private URL getCDUrl(String name) {
        try {
        	URI uri = new URI(cds.get(name));
    		return uri.toURL();
        } catch (URISyntaxException | MalformedURLException e) {
            e.printStackTrace();
            return null;
        } 
    }
}
