package domein;

public class Thee extends HotDrink {

	@Override
	public void brew() {
		System.out.println("Thee zetten");
	}

	@Override
	protected void addCondiments() {
		System.out.println("Suiker en citroen toevoegen");
	}

}
