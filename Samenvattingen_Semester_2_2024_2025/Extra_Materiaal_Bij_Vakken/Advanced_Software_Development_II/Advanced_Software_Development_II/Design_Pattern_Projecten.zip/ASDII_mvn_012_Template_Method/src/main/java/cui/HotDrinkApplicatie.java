package cui;

import domein.ChocolateMilk;
import domein.Koffie;
import domein.Thee;

public class HotDrinkApplicatie {
	public static void main(String[] args) {
		System.out.println("Thee maken: ");
		new Thee().prepareRecipe();

		System.out.println();

		System.out.println("Koffie maken: ");
		new Koffie().prepareRecipe();

		System.out.println();

		System.out.println("Chocolademelk maken: ");
		new ChocolateMilk(true).prepareRecipe();
	}
}
