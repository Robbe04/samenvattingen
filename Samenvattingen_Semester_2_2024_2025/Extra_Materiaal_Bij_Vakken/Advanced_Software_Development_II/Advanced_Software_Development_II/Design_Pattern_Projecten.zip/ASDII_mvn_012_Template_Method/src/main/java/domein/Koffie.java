package domein;

public class Koffie extends HotDrink {

	@Override
	public void brew() {
		System.out.println("Koffie zetten");
	}

	@Override
	protected void addCondiments() {
		System.out.println("Suiker en melk toevoegen");
	}

}
