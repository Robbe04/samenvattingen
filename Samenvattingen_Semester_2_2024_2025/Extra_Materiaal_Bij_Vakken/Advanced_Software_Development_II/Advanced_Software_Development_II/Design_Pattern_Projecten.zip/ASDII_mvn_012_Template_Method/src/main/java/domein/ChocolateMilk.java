package domein;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ChocolateMilk extends HotDrink {

	private boolean wantsCondiments;

	@Override
	public void brew() {
		System.out.println("Chocolademelk maken");
	}

	@Override
	protected void addCondiments() {
		System.out.println("Suiker en slagroom toevoegen");
	}

	@Override
	protected boolean customerWantsCondiments() {
		return wantsCondiments;
	}

}
