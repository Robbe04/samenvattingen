package domein;

public abstract class HotDrink {

	public final void prepareRecipe() {
		boilWater();
		brew();
		pourInCup();
		if (customerWantsCondiments()) {
			addCondiments();
		}
	}

	public void boilWater() {
		System.out.println("Koken van water");
	}

	public abstract void brew();

	protected void pourInCup() {
		System.out.println("Gieten in kopje");
	}

	protected abstract void addCondiments();

	protected boolean customerWantsCondiments() {
		return false;
	}
}
