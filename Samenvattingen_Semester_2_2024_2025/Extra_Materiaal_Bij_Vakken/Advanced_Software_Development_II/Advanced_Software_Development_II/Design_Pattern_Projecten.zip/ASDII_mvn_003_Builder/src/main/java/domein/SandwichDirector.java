package domein;

/**
 * Stap 4: het maken van de director die eenderwelke builder aanstuurt
 */
public class SandwichDirector {
	private Builder builder;

	public SandwichDirector(Builder builder) {
		this.builder = builder;
	}

	public void createSandwitch() {
		builder.createSandwitch();
		builder.buildNaam();
		builder.buildPrijs();
		builder.buildIngredienten();
	}

	public Sandwitch getSandwich() {
		return builder.getSandwitch();
	}
}
