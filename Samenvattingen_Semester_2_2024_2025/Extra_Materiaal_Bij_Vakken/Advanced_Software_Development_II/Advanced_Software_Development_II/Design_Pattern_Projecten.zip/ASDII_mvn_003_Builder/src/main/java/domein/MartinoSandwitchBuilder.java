package domein;

import java.util.List;

/**
 * Stap 3: het maken van de specifieke builder die de domeinklasse in een
 * specifieke volgorde bouwt
 */
public class MartinoSandwitchBuilder extends Builder {

	@Override
	public void buildNaam() {
		getSandwitch().setNaam("Martino");
	}

	@Override
	public void buildPrijs() {
		getSandwitch().setPrijs(3.5);
	}

	@Override
	public void buildIngredienten() {
		getSandwitch().setIngredienten(List.of("Kip", "Mayonaise", "Pikante saus"));
	}

}
