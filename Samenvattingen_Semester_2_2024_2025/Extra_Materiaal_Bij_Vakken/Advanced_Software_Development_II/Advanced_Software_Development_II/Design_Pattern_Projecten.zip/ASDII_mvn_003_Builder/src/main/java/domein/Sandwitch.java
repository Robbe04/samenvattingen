package domein;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Stap 1: het maken van de domeinklasse dat gebuilt moet worden in een
 * specifieke volgorde
 */
@Setter(value = lombok.AccessLevel.PROTECTED)
@Getter
@NoArgsConstructor
public class Sandwitch {
	private String naam;
	private double prijs;
	private List<String> ingredienten;

	@Override
	public String toString() {
		return "Sandwitch{" + "naam='" + naam + '\'' + ", prijs=" + prijs + ", ingredienten=" + ingredienten + '}';
	}
}
