package cui;

import domein.MartinoSandwitchBuilder;
import domein.SandwichDirector;
import domein.Sandwitch;

public class SandwichApplicatie {
	public static void main(String[] args) {
		domein.Builder builder = new MartinoSandwitchBuilder();
		SandwichDirector director = new SandwichDirector(builder);
		director.createSandwitch();
		Sandwitch sandwitch = director.getSandwich();
		System.out.println(sandwitch);

		domein.Builder chickenBuilder = new domein.ChickenSandwichBuilder();
		SandwichDirector chickenDirector = new SandwichDirector(chickenBuilder);
		chickenDirector.createSandwitch();
		Sandwitch chickenSandwitch = chickenDirector.getSandwich();
		System.out.println(chickenSandwitch);
	}
}
