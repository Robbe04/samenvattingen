package domein;

import java.util.List;

public class ChickenSandwichBuilder extends Builder {

	@Override
	public void buildNaam() {
		getSandwitch().setNaam("Sandwich met kip");
	}

	@Override
	public void buildPrijs() {
		getSandwitch().setPrijs(4.0);
	}

	@Override
	public void buildIngredienten() {
		getSandwitch().setIngredienten(List.of("Kip", "Sla", "Tomaat", "Mayonaise"));
	}

}
