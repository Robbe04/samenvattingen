package domein;

import lombok.Getter;

/**
 * 
 */
public abstract class Builder {

	@Getter
	private Sandwitch sandwitch;

	public void createSandwitch() {
		sandwitch = new Sandwitch();
	}

	public abstract void buildNaam();

	public abstract void buildPrijs();

	public abstract void buildIngredienten();
}
