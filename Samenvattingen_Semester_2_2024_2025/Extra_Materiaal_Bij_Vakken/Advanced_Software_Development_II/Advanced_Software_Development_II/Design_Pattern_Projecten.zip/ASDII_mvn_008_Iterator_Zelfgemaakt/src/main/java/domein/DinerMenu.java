package domein;

public class DinerMenu {
	private static final int MAX_ITEMS = 6;
	private int numberOfItems = 0;
	private MenuItem[] menuItems;

	public DinerMenu() {
		menuItems = new MenuItem[MAX_ITEMS];
		addItem("Vegetarische Lasagne", "Een heerlijke vegetarische lasagne met veel groenten", true, 8.99);
		addItem("Steak", "Een sappige steak met kruidenboter", false, 14.99);
		addItem("Vis van de dag", "Dagverse vis met een citroenboter saus", false, 12.99);
		addItem("Vegetarische Burger", "Een burger gemaakt van bonen en groenten", true, 9.99);
	}

	public void addItem(String name, String description, boolean vegetarian, double price) {

		if (numberOfItems >= MAX_ITEMS) {
			System.err.println("Menu is vol, kan geen item toevoegen.");
			return;
		}
		MenuItem menuItem = new MenuItem(name, description, vegetarian, price);
		menuItems[numberOfItems++] = menuItem;
	}

	public Iterator createIterator() {
		return new DinerMenuIterator(menuItems);
	}
}
