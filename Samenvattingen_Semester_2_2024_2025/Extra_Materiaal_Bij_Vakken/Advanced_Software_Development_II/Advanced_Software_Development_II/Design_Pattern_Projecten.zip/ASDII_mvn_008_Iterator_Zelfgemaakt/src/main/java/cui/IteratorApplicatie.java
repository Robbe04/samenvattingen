package cui;

import domein.DinerMenu;
import domein.PancakeHouseMenu;
import domein.Waitress;

public class IteratorApplicatie {
	public static void main(String[] args) {
		PancakeHouseMenu pancakeHouseMenu = new PancakeHouseMenu();
		DinerMenu dinerMenu = new DinerMenu();

		domein.Waitress waitress = new Waitress(pancakeHouseMenu, dinerMenu);

		waitress.printMenu(dinerMenu.createIterator());
		System.out.println();
		waitress.printMenu(pancakeHouseMenu.createIterator());
	}
}
