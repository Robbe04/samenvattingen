package domein;

/**
 * Stap 1: maak een interface Iterator
 */
public interface Iterator {
	boolean hasNext();

	Object next();
}
