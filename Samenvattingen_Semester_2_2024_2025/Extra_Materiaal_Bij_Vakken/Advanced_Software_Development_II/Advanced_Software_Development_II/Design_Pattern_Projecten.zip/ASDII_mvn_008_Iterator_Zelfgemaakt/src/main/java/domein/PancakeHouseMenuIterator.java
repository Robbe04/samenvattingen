package domein;

import java.util.ArrayList;

public class PancakeHouseMenuIterator implements Iterator {

	private ArrayList<MenuItem> menu;
	int position = 0;

	public PancakeHouseMenuIterator(ArrayList<MenuItem> menu) {
		this.menu = menu;
	}

	@Override
	public boolean hasNext() {
		return position < menu.size() && menu.get(position) != null;
	}

	@Override
	public Object next() {
		return menu.get(position++);
	}
}
