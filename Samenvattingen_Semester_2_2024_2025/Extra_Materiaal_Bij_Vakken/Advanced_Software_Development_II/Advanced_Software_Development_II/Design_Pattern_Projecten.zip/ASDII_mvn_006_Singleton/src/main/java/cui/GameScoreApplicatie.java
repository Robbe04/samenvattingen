package cui;

import domein.GameScoreManager;
import domein.GameScoreManager2;

public class GameScoreApplicatie {
	public static void main(String[] args) {
		GameScoreManager gameScoreManager = GameScoreManager.getInstance();
		GameScoreManager gameScoreManager2 = GameScoreManager.getInstance();
		gameScoreManager.add(10);
		gameScoreManager.add(20);
		System.out.println("Result of first gamescore manager: " + gameScoreManager.getScore());
		System.out.println("Result of second gamescore manager: " + gameScoreManager2.getScore());

		GameScoreManager2 gameScoreManager3 = GameScoreManager2.getInstance();

	}
}
