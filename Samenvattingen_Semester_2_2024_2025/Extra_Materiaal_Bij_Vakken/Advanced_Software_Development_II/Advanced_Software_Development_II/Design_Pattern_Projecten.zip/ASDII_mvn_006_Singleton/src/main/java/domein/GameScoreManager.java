package domein;

public class GameScoreManager {

	private int score = 0;

	private static GameScoreManager instance = new GameScoreManager();

	private GameScoreManager() {

	}

	public static GameScoreManager getInstance() {
		return instance;
	}

	public void add(int points) {
		this.score += points;
	}

	public int getScore() {
		return score;
	}
}
