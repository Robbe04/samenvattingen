package domein;

public class GameScoreManager2 {

	static class Singleton {
		private final static GameScoreManager2 INSTANCE = new GameScoreManager2();
	}

	public static GameScoreManager2 getInstance() {
		return Singleton.INSTANCE;
	}
}
