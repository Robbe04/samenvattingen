package domein;

import lombok.Getter;
import lombok.Setter;

public class PersonBeanImpl implements PersonBean {
	@Getter @Setter private String name;
	@Getter @Setter private String gender;
	@Getter @Setter private String interests;
	private int rating;
	private int ratingCount;

	@Override
	public int getHotOrNotRating() {
		if (ratingCount == 0) {
			return 0;
		}
		return rating / ratingCount;
	}

	@Override
	public void setHotOrNotRating(int rating) {
		this.rating += rating;
		ratingCount++;
	}

}
