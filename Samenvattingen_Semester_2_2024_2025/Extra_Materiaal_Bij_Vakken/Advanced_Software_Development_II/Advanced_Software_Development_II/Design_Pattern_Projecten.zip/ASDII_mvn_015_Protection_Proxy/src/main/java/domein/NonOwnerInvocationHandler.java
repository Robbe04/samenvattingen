package domein;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class NonOwnerInvocationHandler implements InvocationHandler {

	private PersonBean person;

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws IllegalAccessException {
		try {
			String methodName = method.getName();

			if (methodName.startsWith("get")) {
				return method.invoke(person, args);
			}
			if (methodName.equals("setHotOrNotRating")) {
				return method.invoke(person, args);
			}
			if (methodName.startsWith("set")) {
				throw new IllegalAccessException();
			}
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}
}
