package domein;

public interface PersonBean {

	public String getName();

	public String getGender();

	public String getInterests();

	public int getHotOrNotRating();

	public void setName(String string);

	public void setGender(String string);

	public void setInterests(String string);

	public void setHotOrNotRating(int i);
}