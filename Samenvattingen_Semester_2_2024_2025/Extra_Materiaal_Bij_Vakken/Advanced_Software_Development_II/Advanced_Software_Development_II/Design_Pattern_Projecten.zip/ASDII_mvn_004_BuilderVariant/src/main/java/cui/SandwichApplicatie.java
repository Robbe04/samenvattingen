package cui;

import java.util.List;

import domein.Sandwich;

public class SandwichApplicatie {
	public static void main(String[] args) {
		Sandwich sandwich = Sandwich.builder().naam("Martino Sandwich").prijs(5.0)
				.ingredienten(List.of("Ham", "Kaas", "Sla", "Tomaat")).build();

		System.out.println(sandwich);
	}
}
