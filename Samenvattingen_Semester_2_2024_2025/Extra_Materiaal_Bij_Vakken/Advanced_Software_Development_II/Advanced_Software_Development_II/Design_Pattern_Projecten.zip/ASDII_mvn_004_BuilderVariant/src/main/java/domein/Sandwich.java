package domein;

import java.util.List;

public class Sandwich {
	private final String naam;
	private final double prijs;
	private final List<String> ingredienten;

	private Sandwich(Builder builder) {
		this.naam = builder.naam;
		this.prijs = builder.prijs;
		this.ingredienten = builder.ingredienten;
	}

	public static Builder builder() {
		return new Builder();
	}

	@Override
	public String toString() {
		return "Sandwich{" + "naam='" + naam + '\'' + ", prijs=" + prijs + ", ingredienten=" + ingredienten + '}';
	}

	public static class Builder {
		private String naam;
		private double prijs;
		private List<String> ingredienten;

		public Builder naam(String naam) {
			this.naam = naam;
			return this;
		}

		public Builder prijs(double prijs) {
			this.prijs = prijs;
			return this;
		}

		public Builder ingredienten(List<String> ingredienten) {
			this.ingredienten = ingredienten;
			return this;
		}

		public Sandwich build() {
			return new Sandwich(this);
		}

	}
}
