package domein;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;

public class CompositeIterator implements Iterator<MenuComponent> {
	Deque<Iterator<MenuComponent>> stack = new ArrayDeque<>();

	public CompositeIterator(Iterator<MenuComponent> iterator) {
		stack.push(iterator);
	}

	public CompositeIterator(MenuComponent root) {
		stack.push(List.of(root).iterator());
	}

	@Override
	public boolean hasNext() {
		if (stack.isEmpty()) {
			return false;
		}

		Iterator<MenuComponent> iterator = stack.peek();
		if (!iterator.hasNext()) {
			stack.pop(); // verwijder lege iterator
			return hasNext(); // controleer de volgende in de stack
		}
		return true; // er is een volgende component
	}

	@Override
	public MenuComponent next() {
		if (hasNext()) {
			Iterator<MenuComponent> iterator = stack.peek();
			MenuComponent component = iterator.next();
			System.out.println(component.getName());
			if (component instanceof Menu) {
				stack.push(component.createIterator());
			}
			return component;
		}
		return null; // geen volgende component
	}

}
