package domein;

import java.util.Collections;
import java.util.Iterator;

import lombok.Getter;

@Getter
public class MenuItem extends MenuComponent {
	private boolean vegetarian;
	private double price;

	public MenuItem(String name, String description, boolean vegetarian, double price) {
		super(name, description);
		this.vegetarian = vegetarian;
		this.price = price;
	}

	@Override
	public void print() {
		System.out.print(" " + getName());
		if (isVegetarian()) {
			System.out.print("(vegetarian)");
		}
		System.out.println(", " + getPrice());
		System.out.println("     -- " + getDescription());
	}

	@Override
	public Iterator<MenuComponent> createIterator() {
		return Collections.emptyIterator();
	}

}
