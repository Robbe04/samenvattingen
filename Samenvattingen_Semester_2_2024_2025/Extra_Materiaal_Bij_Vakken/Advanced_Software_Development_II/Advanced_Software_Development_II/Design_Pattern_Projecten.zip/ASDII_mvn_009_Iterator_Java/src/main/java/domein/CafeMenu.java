package domein;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CafeMenu implements Menu {

	private Map<String, MenuItem> menuItems = new HashMap<>();

	public CafeMenu() {
		addItem("Koffie", "Heerlijke verse koffie", true, 2.50);
		addItem("Thee", "Verfrissende thee", false, 2.00);
		addItem("Broodje Gezond", "Gezond broodje met kaas en ham", true, 3.50);
	}

	private void addItem(String name, String description, boolean isVegetarian, double price) {
		MenuItem menuItem = new MenuItem(name, description, isVegetarian, price);
		menuItems.put(name, menuItem);
	}

	@Override
	public Iterator<MenuItem> createIterator() {
		return menuItems.values().iterator();
	}

	@Override
	public String getTitle() {
		return this.getClass().getSimpleName();
	}

}
