package domein;

import java.util.ArrayList;
import java.util.Iterator;

public class PancakeHouseMenu implements Menu {
	private ArrayList<MenuItem> menu;

	public PancakeHouseMenu() {
		menu = new ArrayList<>();
		addItem("Kleine Pannenkoek", "Een kleine pannenkoek met een beetje stroop", true, 1.99);
		addItem("Grote Pannenkoek", "Een grote pannenkoek met veel stroop", false, 2.99);
		addItem("Pannenkoek met spek", "Een pannenkoek met spek en stroop", false, 3.49);
	}

	private void addItem(String name, String description, boolean vegetarian, double price) {
		MenuItem menuItem = new MenuItem(name, description, vegetarian, price);
		menu.add(menuItem);
	}

	public Iterator<MenuItem> createIterator() {
		return menu.iterator();
	}

	@Override
	public String getTitle() {
		return this.getClass().getSimpleName();
	}
}
