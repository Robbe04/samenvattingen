package domein;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DinerMenuIterator implements Iterator {

	private MenuItem[] items;
	private int position = 0;

	public DinerMenuIterator(MenuItem[] items) {
		this.items = items;
	}

	@Override
	public boolean hasNext() {
		return (position < items.length && items[position] != null);
	}

	@Override
	public Object next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		return items[position++];
	}

	@Override
	public void remove() {
		if (position <= 0) {
			throw new IllegalStateException("Kan geen item verwijderen, er is nog geen item opgehaald.");
		}

		if (items[position - 1] != null) {
			for (int i = position - 1; i < (items.length - 1); i++) {
				items[i] = items[i + 1];
			}
			items[items.length - 1] = null;
		}
	}

}
