package domein;

import java.util.Iterator;
import java.util.List;

public class Waitress {

	private List<Menu> menus;

	public Waitress(List<Menu> menus) {
		this.menus = menus;
	}

	public void printMenu() {
		for (Menu menu : menus) {
			System.out.println("\n" + menu.getTitle());
			System.out.println("--------------------");

			Iterator<MenuItem> menuIterator = menu.createIterator();
			printMenu(menuIterator);
		}
	}

	public void printMenu(Iterator<MenuItem> iterator) {
		while (iterator.hasNext()) {
			MenuItem menuItem = iterator.next();
			System.out.println(menuItem.getName() + ", " + menuItem.getPrice() + " -- " + menuItem.getDescription());
		}
	}
}
