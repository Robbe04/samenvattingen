package domein;

public class KalkoenAdapter implements Eend {

	private Kalkoen kalkoen;

	public KalkoenAdapter(Kalkoen kalkoen) {
		this.kalkoen = kalkoen;
	}

	@Override
	public void quack() {
		kalkoen.gobble();
	}

	@Override
	public void swim() {
		kalkoen.fly();
	}

}
