package domein;

public class MalardEend implements Eend {

	@Override
	public void quack() {
		System.out.println("Quack quack");
	}

	@Override
	public void swim() {
		System.out.println("Swimming in a lake");
	}

}
