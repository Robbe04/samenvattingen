package domein;

public interface Eend {
	void quack();

	void swim();
}
