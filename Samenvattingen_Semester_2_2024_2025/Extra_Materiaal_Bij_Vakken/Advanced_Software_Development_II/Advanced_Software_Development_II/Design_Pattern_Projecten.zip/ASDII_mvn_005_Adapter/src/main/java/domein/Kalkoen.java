package domein;

public interface Kalkoen {
	void gobble();

	void fly();
}
