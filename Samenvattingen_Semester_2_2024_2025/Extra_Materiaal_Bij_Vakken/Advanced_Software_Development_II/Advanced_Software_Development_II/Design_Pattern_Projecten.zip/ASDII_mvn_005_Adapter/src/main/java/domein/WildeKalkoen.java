package domein;

public class WildeKalkoen implements Kalkoen {

	@Override
	public void gobble() {
		System.out.println("gobble gobble");
	}

	@Override
	public void fly() {
		System.out.println("flying a short distance");
	}

}
