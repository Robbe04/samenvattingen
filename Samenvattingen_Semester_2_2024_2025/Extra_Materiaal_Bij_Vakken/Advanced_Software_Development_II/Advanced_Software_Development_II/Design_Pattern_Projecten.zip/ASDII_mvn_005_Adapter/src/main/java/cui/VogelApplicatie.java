package cui;

import domein.Eend;
import domein.Kalkoen;
import domein.KalkoenAdapter;
import domein.MalardEend;
import domein.WildeKalkoen;

public class VogelApplicatie {

	public static void main(String[] args) {
		Eend eend = new MalardEend();
		System.out.println("De eend zegt: ");
		eend.quack();
		eend.swim();
		System.out.println();

		Kalkoen kalkoen = new WildeKalkoen();
		System.out.println("De kalkoen zegt: ");
		kalkoen.gobble();
		kalkoen.fly();
		System.out.println();

		KalkoenAdapter kalkoenEend = new KalkoenAdapter(new WildeKalkoen());
		System.out.println("De 'eend' zegt: ");
		kalkoenEend.quack();
		kalkoenEend.swim();
	}
}
