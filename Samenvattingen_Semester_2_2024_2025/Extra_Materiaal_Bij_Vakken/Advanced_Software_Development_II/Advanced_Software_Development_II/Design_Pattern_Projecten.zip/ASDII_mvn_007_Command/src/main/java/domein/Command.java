package domein;

/**
 * Step 1: Make a Command interface with all the possible methods/commands
 */
public interface Command {

	void execute();

}
