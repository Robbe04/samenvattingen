package domein;

import lombok.Getter;
import lombok.Setter;

/**
 * Step 2: Create a object that will be controlled by the command
 */
public class Light {
	@Getter
	@Setter
	private String name;

	public Light(String name) {
		this.name = name;
	}

	public Light() {

	}

	public void on() {
		System.out.println("Light from " + getName() + " is on");
	}

	public void off() {
		System.out.println("Light from " + getName() + " is off");
	}
}