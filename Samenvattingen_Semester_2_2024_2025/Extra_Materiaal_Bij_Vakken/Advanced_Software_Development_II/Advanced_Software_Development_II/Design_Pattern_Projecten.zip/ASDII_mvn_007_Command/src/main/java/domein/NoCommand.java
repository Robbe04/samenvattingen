package domein;

public class NoCommand implements Command {

	@Override
	public void execute() {
	}

}
