package domein;

/**
 * Step 3: Create a concrete command that implements the Command interface to
 * control the Light object
 */
public class LightOnCommand implements Command {

	private Light light;

	public LightOnCommand(Light light) {
		this.light = light;
	}

	@Override
	public void execute() {
		light.on();
	}

}
