package domein;

/**
 * Step 4: Create an object that will execute these commands
 */
public class SimpleRemoteControl {
	private Command slot;

	public void setCommand(Command command) {
		this.slot = command;
	}

	public void buttonWasPressed() {
		slot.execute();
	}
}
