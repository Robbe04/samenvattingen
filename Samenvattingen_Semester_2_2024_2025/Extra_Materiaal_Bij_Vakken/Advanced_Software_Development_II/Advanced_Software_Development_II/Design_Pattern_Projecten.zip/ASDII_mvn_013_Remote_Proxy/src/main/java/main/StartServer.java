package main;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import domein.GumballMachine;

public class StartServer {
	public static void main(String[] args) {
		try {
			Registry registry = LocateRegistry.createRegistry(1099);
			System.out.println("RMI Registry started on port 1099");

			GumballMachine gumballMachine = new GumballMachine("Seattle", 100);

			registry.rebind("gumballmachine", gumballMachine);

			System.out.println("GumballMachine server ready");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
}
