package domein;

import java.io.Serializable;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public abstract class GumballMachineState implements Serializable {

	private static final long serialVersionUID = 1L;

	transient protected final GumballMachine gumballMachine;

	public String insertQuarter() {
		return "You can't insert a quarter";
	}

}
