package domein;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * Stap 2: GumballMachine klaarzetten als remote service
 */
public class GumballMachine extends UnicastRemoteObject implements GumballMachineRemote {

	private static final long serialVersionUID = 1L;

	@Setter(value = AccessLevel.PRIVATE)
	private GumballMachineState currentState;

	@Getter
	private int count = 0;

	@Getter
	private final String location;

	public GumballMachine(String location, int numberOfGumballs) throws RemoteException {
		this.location = location;
		this.count = numberOfGumballs;

	}

	public String insertQuarter() throws RemoteException {
		return currentState.insertQuarter();
	}

	@Override
	public String getState() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

}
