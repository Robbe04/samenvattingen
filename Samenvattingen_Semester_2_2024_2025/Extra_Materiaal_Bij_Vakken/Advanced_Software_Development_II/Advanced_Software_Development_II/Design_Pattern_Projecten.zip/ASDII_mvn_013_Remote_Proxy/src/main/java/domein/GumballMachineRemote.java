
package domein;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Stap 1: Maak een interface GumballMachineRemote aan die Remote implmenteert.
 */
public interface GumballMachineRemote extends Remote {
	int getCount() throws RemoteException;

	String getLocation() throws RemoteException;

	String getState() throws RemoteException;
}
